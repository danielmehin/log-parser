import express, { Request, Response } from 'express';
import fs from 'fs';
import { promisify } from 'util';

var cors = require('cors')

const readFileAsync = promisify(fs.readFile);
const app = express();

app.use(cors());

interface LogEntry {
    ip: string;
    dateTime: string;
    method: string;
    url: string;
    status: string;
    userAgent: string;
}

app.get('/api', (req: Request, res: Response) => {
    readFileAsync('logfile.log', 'utf8')
    .then(data => {
        const ipPattern = /([\d\.]+)/;
        const dateTimePattern = /\[(.*?)\]/;
        const requestPattern = /"(.*?)"/;
        const statusPattern = /\s(\d{3})\s/;
        const userAgentPattern = /"([^"]*)"\s*$/;

        const logs: LogEntry[] = [];

        data.split('\n').forEach(line => {
            const ipMatch = line.match(ipPattern);
            const dateTimeMatch = line.match(dateTimePattern);
            const requestMatch = line.match(requestPattern);
            const statusMatch = line.match(statusPattern);
            const userAgentMatch = line.match(userAgentPattern);

            if (ipMatch && dateTimeMatch && requestMatch && statusMatch && userAgentMatch) {
                const ip = ipMatch[1];
                const dateTime = dateTimeMatch[1];
                const [method, url] = requestMatch[1].split(' ');
                const status = statusMatch[1];
                const userAgent = userAgentMatch[1];

                const log: LogEntry = {
                    ip,
                    dateTime,
                    method,
                    url,
                    status,
                    userAgent
                };

                logs.push(log);
            }
        });

        res.json(logs);
    })
    .catch(err => {
        console.error(err);
        return res.status(500).send('Error reading log file');
    });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

export default app
