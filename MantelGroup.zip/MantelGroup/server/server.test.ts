import request from 'supertest';
import app from './server';
jest.mock('fs');

const fs = require('fs');

describe('/api route', () => {
  it('should convert log file to JSON successfully', async () => {
    const mockData = `123.123.123.123 [10/Oct/2000:13:55:36 -0700] "GET /api/path HTTP/1.0" 200 "Mozilla/5.0"`;
    fs.readFile.mockImplementation((_path: string, _encoding: string, callback: (err: NodeJS.ErrnoException | null, data: string) => void) => {
      callback(null, mockData);
    });

    const response = await request(app).get('/api');
    
    expect(response.status).toBe(200);
    expect(response.body).toEqual([
      {
        ip: '123.123.123.123',
        dateTime: '10/Oct/2000:13:55:36 -0700',
        method: 'GET',
        url: '/api/path',
        status: '200',
        userAgent: 'Mozilla/5.0',
      },
    ]);
  });

  it('should return 500 if reading log file fails', async () => {
    fs.readFile.mockImplementation(
      (_path: string, _encoding: string, callback: (err: NodeJS.ErrnoException | null, data: string | null) => void) => {
        callback(new Error('Error reading log file'), null);
      }
    );

    const response = await request(app).get('/api');
    expect(response.status).toBe(500);
    expect(response.text).toEqual('Error reading log file');
  });
});
