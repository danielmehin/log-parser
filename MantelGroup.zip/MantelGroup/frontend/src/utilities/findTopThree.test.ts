import findTopThree from "./findTopThree";

const mockData = [
  { ip: '192.168.1.1', datetime: '2022-03-01', method: 'GET', status: '200', url: 'http://example.com', useragent: 'Mozilla' },
  { ip: '192.168.1.2', datetime: '2022-03-02', method: 'POST', status: '404', url: 'http://example.com/page', useragent: 'Chrome' },
  { ip: '192.168.1.1', datetime: '2022-03-03', method: 'GET', status: '200', url: 'http://example.com', useragent: 'Mozilla' },
  { ip: '192.168.1.3', datetime: '2022-03-04', method: 'POST', status: '500', url: 'http://example.org', useragent: 'Safari' },
  { ip: '192.168.1.2', datetime: '2022-03-05', method: 'GET', status: '404', url: 'http://example.com/page', useragent: 'Chrome' },
  { ip: '192.168.1.2', datetime: '2022-03-06', method: 'GET', status: '404', url: 'http://example.com/page', useragent: 'Chrome' },
];

describe('findTopThree', () => {
  it('correctly finds the top three IPs', () => {
    const result = findTopThree(mockData, 'ip');
    expect(result).toEqual([
      { key: '192.168.1.2', count: 3 },
      { key: '192.168.1.1', count: 2 },
      { key: '192.168.1.3', count: 1 }
    ]);
  });

  it('correctly finds the top three URLs', () => {
    const result = findTopThree(mockData, 'url');
    expect(result).toEqual([
      { key: 'http://example.com/page', count: 3 },
      { key: 'http://example.com', count: 2 },
      { key: 'http://example.org', count: 1 }
    ]);
  });

  it('returns fewer than three items if not enough unique keys', () => {
    const smallData = [
      { ip: '192.168.1.1', datetime: '2022-03-01', method: 'GET', status: '200', url: 'http://example.com', useragent: 'Mozilla' },
      { ip: '192.168.1.2', datetime: '2022-03-02', method: 'POST', status: '404', url: 'http://example.com/page', useragent: 'Chrome' }
    ];
    const result = findTopThree(smallData, 'ip');
    expect(result).toHaveLength(2);
  });

  it('returns an empty array if no data provided', () => {
    const result = findTopThree([], 'ip');
    expect(result).toEqual([]);
  });
});