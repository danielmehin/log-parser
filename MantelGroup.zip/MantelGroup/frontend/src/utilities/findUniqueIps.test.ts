import findUniqueIps from './findUniqueIps';
import type { DataItem } from '../types/dataItem';

describe('findUniqueIps', () => {
  it('filters out duplicate IP addresses', () => {
    const mockData: DataItem[] = [ 
      { ip: '192.168.1.1', datetime: '', method: '', status: '', url: '', useragent: '' },
      { ip: '192.168.1.2', datetime: '', method: '', status: '', url: '', useragent: '' },
      { ip: '192.168.1.1', datetime: '', method: '', status: '', url: '', useragent: '' },
    ];

    const uniqueIPs = findUniqueIps(mockData);
    expect(uniqueIPs).toHaveLength(2);
    expect(uniqueIPs).toEqual(expect.arrayContaining([
      expect.objectContaining({ ip: '192.168.1.1' }),
      expect.objectContaining({ ip: '192.168.1.2' })
    ]));
  });

  it('returns an empty array for no data', () => {
    const mockData: DataItem[] = []; 
    const uniqueIPs = findUniqueIps(mockData);
    expect(uniqueIPs).toEqual([]);
  });

  it('returns the same array if all IPs are unique', () => {
    const mockData: DataItem[] = [
      { ip: '192.168.1.1', datetime: '', method: '', status: '', url: '', useragent: '' },
      { ip: '192.168.1.2', datetime: '', method: '', status: '', url: '', useragent: '' },
    ];

    const uniqueIPs = findUniqueIps(mockData);
    expect(uniqueIPs).toHaveLength(2);
    expect(uniqueIPs).toEqual(mockData);
  });
});
