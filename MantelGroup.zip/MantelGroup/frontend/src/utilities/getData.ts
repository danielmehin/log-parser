const getData = async <T>(apiUrl: string): Promise<T> => {
  const res = await fetch(apiUrl);
  const data: T = await res.json();
  return data;
}

export default getData