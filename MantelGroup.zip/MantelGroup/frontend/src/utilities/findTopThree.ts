import type { DataItem } from '../types/dataItem'

type CountResult = { key: string; count: number };

function findTopThree<T extends keyof DataItem>(data: DataItem[], key: T): CountResult[] {
  const visitCount = new Map<string, number>();
  
  data.forEach(item => {
    const keyValue = item[key];
    visitCount.set(keyValue, (visitCount.get(keyValue) || 0) + 1);
  });

  const topVisited = Array.from(visitCount.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([key, count]) => ({ key, count }));

  return topVisited;
}

export default findTopThree