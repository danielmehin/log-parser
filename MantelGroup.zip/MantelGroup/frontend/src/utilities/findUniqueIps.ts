import type { DataItem } from '../types/dataItem'

const findUniqueIps = (data: DataItem[]): DataItem[] => {
  let uniqueIPs: DataItem[] = [];

  data.forEach(obj => {
    if (!uniqueIPs.find(uniqueObj => uniqueObj.ip === obj.ip)) {
      uniqueIPs = [...uniqueIPs, obj];
    }
  })

  return uniqueIPs
}

export default findUniqueIps