import styled from 'styled-components'

const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  @media (min-width: 48rem) {
    flex-direction: row;
    align-items: stretch;
  }
`

const Heading = styled.h1`
  font-size: 3rem;
  text-align: center;
  margin: 2rem auto 4rem;
`

export {Wrapper, Heading} 