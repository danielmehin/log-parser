import { useState, useEffect } from 'react'
import GlobalStyles from './globalStyles'
import getData from './utilities/getData'
import findTopThree from './utilities/findTopThree'
import findUniqueIps from './utilities/findUniqueIps'
import List from './components/list'
import Table from './components/table'
import Footer from './components/Footer'
import type { DataItem } from './types/dataItem'
import { Wrapper, Heading } from './app.styles'

function App() {
  const [data, setData] = useState<DataItem[]>([]);
  const apiUrl = import.meta.env.VITE_API_URL;

  useEffect(() => {
    getData<DataItem[]>(apiUrl).then(res => setData(res))
  }, [])

  return (
    <>
      <GlobalStyles />
      <Heading>Log dashboard</Heading>
      <Wrapper>
        <List listData={findUniqueIps(data)} />
        <Table tableData={findTopThree(data, 'url')}></Table>
        <Table tableData={findTopThree(data, 'ip')}></Table>
      </Wrapper>
      <Footer />
    </>
  )
}

export default App
