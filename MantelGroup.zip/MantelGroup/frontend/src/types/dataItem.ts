interface DataItem {
  ip: string,
  datetime: string,
  method: string,
  status: string,
  url: string,
  useragent: string
}

export type { DataItem } 