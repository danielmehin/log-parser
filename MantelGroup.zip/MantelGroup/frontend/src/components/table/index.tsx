import { Wrapper, Heading, TableRow, TableDef } from "./table.styles"

type CountResult = { key: string; count: number };

interface TableProps {
  tableData: CountResult[];
}

const Table: React.FC<TableProps> = ({ tableData }) => {
  return <Wrapper>
  <Heading>Most visited</Heading>
  <table>
    <thead>
      <TableRow>
        <TableDef>Keys</TableDef>
        <TableDef>Count</TableDef>
      </TableRow>
    </thead>
    <tbody>
      {tableData.map((item, index) => (
        <TableRow key={index}>
          <TableDef>{item.key}</TableDef><TableDef>{item.count}</TableDef>
        </TableRow>
      ))}
    </tbody>
  </table>
</Wrapper>
}

export default Table