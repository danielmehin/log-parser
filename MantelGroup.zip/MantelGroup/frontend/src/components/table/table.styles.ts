import styled from 'styled-components'

const Wrapper = styled.div`
  padding: 1rem;
  margin: 1rem;
  background: #323232;
  border-radius: 10px;
  flex-grow: 1
`
const Heading = styled.h2`
  font-size: 1.5rem;
  margin: 0 0 1rem 0;
`
const TableRow = styled.tr`
  margin: 0;
  padding: 0;
`

const TableDef = styled.td`
  Padding: 0 2rem .5rem 0;
`

export { Wrapper, Heading, TableRow, TableDef } 