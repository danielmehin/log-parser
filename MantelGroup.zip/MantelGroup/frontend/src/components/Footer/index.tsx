import { Wrapper } from './footer.styles'

function Footer() {
  return (
    <Wrapper>This is a &copy;copyright of Dan M</Wrapper>
  )
}

export default Footer