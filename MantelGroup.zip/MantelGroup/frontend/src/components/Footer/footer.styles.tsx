import styled from 'styled-components'

const Wrapper = styled.div`
  padding: 1rem;
  font-size: .75rem;
  background: #000000;
  text-align: center;
  width: 100%;

  @media (min-width: 48rem) {
    position: fixed;
    bottom: 0;
  }
`

export { Wrapper }