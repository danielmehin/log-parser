import type { DataItem } from '../../types/dataItem'
import { Wrapper, Heading, ListUL, ListItem } from "./list.styles"

interface ListProps {
  listData: DataItem[];
}

function List({ listData }: ListProps) {
  return (
    <Wrapper>
      <Heading>Unique Ips</Heading>
      <ListUL>
        {listData.map((item, index) => (
          <ListItem key={`${index}-${item.ip}`}>
            <span>{item.ip}</span> - <span>{item.url}</span>
          </ListItem>
        ))}
      </ListUL>
    </Wrapper>
  );
}

export default List;