import styled from 'styled-components'

const Wrapper = styled.div`
  padding: 1rem;
  margin: 1rem;
  background: #323232;
  border-radius: 10px;
  flex-grow: 1;
`
const Heading = styled.h2`
  font-size: 1.5rem;
  margin: 0 0 1rem 0;
`
const ListUL = styled.ul`
  list-style: none;
  margin: 0;
  padding: 0;
`

const ListItem = styled.li`
  margin: 0 0 .5rem 0;
`

export { Wrapper, Heading, ListUL, ListItem } 